import React from "react";
import WeeklyCalendar from "./Components/WeeklyCalendar";

const App = () => {
  return (
    <div className="App">
      <WeeklyCalendar />
    </div>
  );
};

export default App;
